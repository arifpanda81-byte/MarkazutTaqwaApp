package com.markazuttaqwa.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Black = Color(0xFF080808)
private val Card = Color(0xFF151515)
private val Gold = Color(0xFFE7B85A)
private val Muted = Color(0xFFB9B0A0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App() } }
}

data class Notice(val title:String, val date:String, val important:Boolean, val body:String)

@Composable fun App() {
    var page by remember { mutableStateOf("home") }
    var selected by remember { mutableStateOf<Notice?>(null) }
    MaterialTheme(colorScheme = darkColorScheme(background=Black, surface=Card, primary=Gold, onPrimary=Black, onBackground=Color.White, onSurface=Color.White)) {
        Surface(Modifier.fillMaxSize(), color=Black) {
            when {
                selected != null -> NoticeDetail(selected!!) { selected=null }
                page == "home" -> Home(onNotice={selected=it}, onPage={page=it})
                page == "notice" -> Notices(onBack={page="home"}, onNotice={selected=it})
                page == "routine" -> SimplePage("রুটিন", "সাপ্তাহিক ক্লাস রুটিন", Icons.Default.CalendarMonth) { page="home" }
                else -> SimplePage("প্রোফাইল", "মোঃ তাহসিন\nশিক্ষক\nমারকাজুত তাকওয়া হাফেজিয়া মাদ্রাসা", Icons.Default.Person) { page="home" }
            }
        }
    }
}

val notices = listOf(
    Notice("বার্ষিক পরীক্ষা ২০২৬ এর সময়সূচি প্রকাশ", "০১ সেপ্টেম্বর ২০২৬", true, "সকল শিক্ষক ও শিক্ষার্থীদের জানানো যাচ্ছে যে বার্ষিক পরীক্ষা ২০২৬ এর সময়সূচি প্রকাশ করা হয়েছে। নির্ধারিত সময়ের ১৫ মিনিট আগে উপস্থিত থাকতে হবে।"),
    Notice("সাপ্তাহিক ছুটির নোটিশ", "৩০ আগস্ট ২০২৬", false, "আগামী শুক্রবার মাদ্রাসার নিয়মিত কার্যক্রম বন্ধ থাকবে। শনিবার থেকে যথারীতি ক্লাস শুরু হবে।")
)

@Composable fun Header(title:String, back: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment=Alignment.CenterVertically) {
        if(back!=null) IconButton(onClick=back) { Icon(Icons.Default.ArrowBack, null, tint=Gold) } else Icon(Icons.Default.Menu, null, tint=Gold, modifier=Modifier.size(28.dp))
        Text(title, Modifier.weight(1f), textAlign=TextAlign.Center, color=Gold, fontSize=20.sp, fontWeight=FontWeight.Bold)
        Icon(Icons.Default.NotificationsNone, null, tint=Gold, modifier=Modifier.size(27.dp))
    }
}

@Composable fun Home(onNotice:(Notice)->Unit, onPage:(String)->Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("মারকাজুত তাকওয়া")
        LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
            item { WelcomeCard() }
            item { SectionTitle("গুরুত্বপূর্ণ নোটিশ") }
            item { NoticeCard(notices[0], onNotice) }
            item { SectionTitle("দ্রুত মেনু") }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                Menu("নোটিশ", Icons.Default.Notifications, Modifier.weight(1f)) { onPage("notice") }
                Menu("রুটিন", Icons.Default.CalendarMonth, Modifier.weight(1f)) { onPage("routine") }
                Menu("প্রোফাইল", Icons.Default.Person, Modifier.weight(1f)) { onPage("profile") }
            }}
            item { SectionTitle("সাম্প্রতিক নোটিশ") }
            items(notices) { n -> NoticeCard(n, onNotice) }
        }
    }
}

@Composable fun WelcomeCard() { Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(22.dp), colors=CardDefaults.cardColors(containerColor=Card)) {
    Column(Modifier.padding(22.dp)) {
        Text("আসসালামু আলাইকুম", color=Muted, fontSize=14.sp)
        Text("মোঃ তাহসিন", color=Gold, fontSize=25.sp, fontWeight=FontWeight.Bold)
        Text("শিক্ষক", color=Color.White.copy(alpha=.8f), fontSize=14.sp)
        Spacer(Modifier.height(14.dp)); Divider(color=Gold.copy(alpha=.25f)); Spacer(Modifier.height(12.dp))
        Text("মারকাজুত তাকওয়া হাফেজিয়া মাদ্রাসা", color=Color.White, fontSize=16.sp, fontWeight=FontWeight.SemiBold)
        Text("ইলম • তাকওয়া • আমল", color=Gold, fontSize=13.sp, modifier=Modifier.padding(top=4.dp))
    }
} }

@Composable fun SectionTitle(t:String) { Text(t, color=Gold, fontSize=17.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(top=4.dp)) }

@Composable fun NoticeCard(n:Notice, onClick:(Notice)->Unit) { Card(Modifier.fillMaxWidth().clickable{onClick(n)}, shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=Card)) {
    Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
        Icon(if(n.important) Icons.Default.Campaign else Icons.Default.Description, null, tint=Gold, modifier=Modifier.size(30.dp)); Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) { Text(n.title, color=Color.White, fontWeight=FontWeight.SemiBold, fontSize=15.sp); Text(n.date, color=Muted, fontSize=12.sp, modifier=Modifier.padding(top=5.dp)) }
        Icon(Icons.Default.ChevronRight, null, tint=Gold)
    }
} }

@Composable fun Menu(label:String, icon:androidx.compose.ui.graphics.vector.ImageVector, modifier:Modifier, onClick:()->Unit) { Card(modifier.clickable{onClick()}, shape=RoundedCornerShape(16.dp), colors=CardDefaults.cardColors(containerColor=Card)) { Column(Modifier.padding(vertical=18.dp).fillMaxWidth(), horizontalAlignment=Alignment.CenterHorizontally) { Icon(icon,null,tint=Gold); Text(label,color=Color.White,fontSize=12.sp,modifier=Modifier.padding(top=7.dp)) } } }

@Composable fun Notices(onBack:()->Unit, onNotice:(Notice)->Unit) { Column(Modifier.fillMaxSize()) { Header("নোটিশ", onBack); LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) { items(notices){ NoticeCard(it,onNotice) } } } }

@Composable fun NoticeDetail(n:Notice, onBack:()->Unit) { Column(Modifier.fillMaxSize()) { Header("নোটিশ বিস্তারিত", onBack); LazyColumn(contentPadding=PaddingValues(18.dp)) { item { Text(n.date,color=Gold,fontSize=13.sp); Spacer(Modifier.height(12.dp)); Text(n.title,color=Color.White,fontSize=27.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(18.dp)); Divider(color=Gold.copy(alpha=.35f)); Spacer(Modifier.height(18.dp)); Text(n.body,color=Muted,fontSize=16.sp,lineHeight=28.sp); Spacer(Modifier.height(28.dp)); Button(onClick={}, colors=ButtonDefaults.buttonColors(containerColor=Gold), shape=RoundedCornerShape(14.dp), modifier=Modifier.fillMaxWidth().height(52.dp)) { Icon(Icons.Default.Download,null,tint=Black); Spacer(Modifier.width(8.dp)); Text("ডাউনলোড / শেয়ার",color=Black,fontWeight=FontWeight.Bold) } } } } }

@Composable fun SimplePage(title:String, text:String, icon:androidx.compose.ui.graphics.vector.ImageVector, back:()->Unit) { Column(Modifier.fillMaxSize()) { Header(title,back); Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){ Column(horizontalAlignment=Alignment.CenterHorizontally){ Icon(icon,null,tint=Gold,modifier=Modifier.size(70.dp)); Spacer(Modifier.height(16.dp)); Text(text,color=Color.White,textAlign=TextAlign.Center,fontSize=20.sp,lineHeight=30.sp) } } } }
